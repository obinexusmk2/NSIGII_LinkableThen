/*
 * nsigii_audio_lte.c — NSIGII LTE Audio WAV Verifier
 * OBINexus SDK | MMUKO OS Design and Technology LLC
 * Author: Nnamdi Michael Okpala
 *
 * PRINCIPLE: Linkable Then Executable applied to audio.
 * Every WAV chunk is LINKED (hashed) before it can be PLAYED (executed).
 * PLAY  = RELAY   (advance to next verified frame)
 * PAUSE = STOP    (halt, maintain state, recheck hash on resume)
 * SEEK  = BACKTRACK (return to prior verified frame)
 *
 * WAV format (PCM):
 *   [RIFF header 44 bytes] [audio data frames...]
 *   Each CHUNK_SIZE bytes of audio = one LTE artifact.
 */

#include "nsigii_lte.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <signal.h>
#include <time.h>

/* ─── Config ──────────────────────────────────────────────────────────────── */

#define CHUNK_BYTES     4096        /* bytes per audio chunk / LTE artifact  */
#define MAX_CHUNKS      2048        /* max chunks we will verify             */
#define SAMPLE_RATE     44100       /* expected WAV sample rate              */

/* ─── ODTS playback states (from ODTS README) ────────────────────────────── */

typedef enum {
    ODTS_STOPPED  = 0,   /* D0 — no movement                    */
    ODTS_PLAYING  = 1,   /* D1 — velocity: advancing frames     */
    ODTS_PAUSED   = 2,   /* D2 — curvature: halted mid-stream   */
    ODTS_SEEKING  = 3,   /* D3 — jerk: repositioning            */
    ODTS_REJECTED = 4    /* D6 — collapse: hash failed          */
} ODTSState;

/* ─── WAV header (44 bytes, PCM) ─────────────────────────────────────────── */

typedef struct __attribute__((packed)) {
    char     riff[4];           /* "RIFF"                  */
    uint32_t file_size;         /* total file - 8          */
    char     wave[4];           /* "WAVE"                  */
    char     fmt[4];            /* "fmt "                  */
    uint32_t fmt_size;          /* 16 for PCM              */
    uint16_t audio_format;      /* 1 = PCM                 */
    uint16_t num_channels;      /* 1=mono, 2=stereo        */
    uint32_t sample_rate;
    uint32_t byte_rate;
    uint16_t block_align;
    uint16_t bits_per_sample;
    char     data[4];           /* "data"                  */
    uint32_t data_size;
} WAVHeader;

/* ─── Player state ────────────────────────────────────────────────────────── */

typedef struct {
    /* file */
    FILE       *file;
    WAVHeader   header;
    size_t      data_offset;    /* byte offset where audio data starts */
    size_t      total_chunks;
    size_t      current_chunk;

    /* LTE chain */
    LTEChain    chain;
    uint8_t     chunk_buf[CHUNK_BYTES];
    size_t      chunk_sizes[MAX_CHUNKS];  /* actual bytes in each chunk */

    /* ODTS state */
    ODTSState   state;
    double      playback_speed; /* 0.5, 1.0, 1.5, 2.0               */

    /* stats */
    size_t      frames_verified;
    size_t      frames_played;
    size_t      tamper_count;
} NSIGIIPlayer;

/* ─── Globals for signal handler ──────────────────────────────────────────── */

static volatile int g_pause_requested = 0;
static volatile int g_quit_requested  = 0;

static void signal_handler(int sig) {
    if (sig == SIGINT)  g_pause_requested = 1;
    if (sig == SIGTERM) g_quit_requested  = 1;
}

/* ─── WAV helpers ─────────────────────────────────────────────────────────── */

static int wav_open(NSIGIIPlayer *p, const char *path) {
    p->file = fopen(path, "rb");
    if (!p->file) {
        fprintf(stderr, "[LTE] Cannot open: %s\n", path);
        return -1;
    }

    if (fread(&p->header, sizeof(WAVHeader), 1, p->file) != 1) {
        fprintf(stderr, "[LTE] Cannot read WAV header\n");
        return -1;
    }

    if (memcmp(p->header.riff, "RIFF", 4) != 0 ||
        memcmp(p->header.wave, "WAVE", 4) != 0) {
        fprintf(stderr, "[LTE] Not a valid WAV file\n");
        return -1;
    }

    p->data_offset   = sizeof(WAVHeader);
    p->total_chunks  = (p->header.data_size + CHUNK_BYTES - 1) / CHUNK_BYTES;
    if (p->total_chunks > MAX_CHUNKS) p->total_chunks = MAX_CHUNKS;

    printf("[LTE] WAV opened\n");
    printf("      Channels    : %u\n", p->header.num_channels);
    printf("      Sample rate : %u Hz\n", p->header.sample_rate);
    printf("      Bits/sample : %u\n", p->header.bits_per_sample);
    printf("      Data size   : %u bytes\n", p->header.data_size);
    printf("      Chunks      : %zu x %d bytes\n", p->total_chunks, CHUNK_BYTES);
    return 0;
}

/* ─── Phase 1: LINK — hash every chunk before playback ───────────────────── */

static int lte_link_all_chunks(NSIGIIPlayer *p) {
    printf("\n[LTE LINK] Hashing all %zu chunks...\n", p->total_chunks);

    fseek(p->file, (long)p->data_offset, SEEK_SET);

    uint8_t prev[LTE_HASH_SIZE];
    memset(prev, 0, LTE_HASH_SIZE);

    for (size_t i = 0; i < p->total_chunks; i++) {
        size_t n = fread(p->chunk_buf, 1, CHUNK_BYTES, p->file);
        if (n == 0) break;
        p->chunk_sizes[i] = n;

        LTEArtifact artifact;
        memset(&artifact, 0, sizeof(artifact));

        char name[LTE_NAME_SIZE];
        snprintf(name, sizeof(name), "audio_chunk_%04zu", i);

        LTEResult r = lte_link(&artifact, name, p->chunk_buf, n, prev);
        if (r != LTE_OK) {
            fprintf(stderr, "[LTE LINK] Failed on chunk %zu: %s\n",
                    i, lte_result_label(r));
            return -1;
        }

        memcpy(prev, artifact.link_hash, LTE_HASH_SIZE);

        r = lte_chain_append(&p->chain, &artifact);
        if (r != LTE_OK) {
            fprintf(stderr, "[LTE LINK] Chain append failed chunk %zu: %s\n",
                    i, lte_result_label(r));
            return -1;
        }

        if (i % 50 == 0 || i == p->total_chunks - 1)
            printf("  linked %zu/%zu  hash: %.16s...\n",
                   i + 1, p->total_chunks,
                   p->chain.artifacts[i].link_hex);
    }

    printf("[LTE LINK] COMPLETE — %zu artifacts in chain\n", p->chain.count);
    return 0;
}

/* ─── Phase 2: EXECUTE — play with real-time verify on each chunk ─────────── */

static void print_state(ODTSState s) {
    switch (s) {
        case ODTS_PLAYING:  printf("[RELAY  ] "); break;
        case ODTS_PAUSED:   printf("[STOP   ] "); break;
        case ODTS_SEEKING:  printf("[BACK   ] "); break;
        case ODTS_REJECTED: printf("[REJECT ] "); break;
        default:            printf("[IDLE   ] "); break;
    }
}

static int lte_play(NSIGIIPlayer *p) {
    printf("\n[LTE EXECUTE] Starting playback — Ctrl+C to PAUSE/RESUME\n\n");

    p->state          = ODTS_PLAYING;
    p->playback_speed = 1.0;
    p->current_chunk  = 0;

    fseek(p->file, (long)p->data_offset, SEEK_SET);

    while (p->current_chunk < p->chain.count && !g_quit_requested) {

        /* ── PAUSE toggle ── */
        if (g_pause_requested) {
            g_pause_requested = 0;
            if (p->state == ODTS_PLAYING) {
                p->state = ODTS_PAUSED;
                printf("\n[STOP] Paused at chunk %zu/%zu  "
                       "Press Ctrl+C again to resume.\n",
                       p->current_chunk, p->chain.count);
                /* spin-wait while paused */
                while (p->state == ODTS_PAUSED && !g_pause_requested
                       && !g_quit_requested) {
                    struct timespec ts = {0, 50000000}; /* 50ms poll */
                    nanosleep(&ts, NULL);
                }
                if (g_pause_requested) {
                    g_pause_requested = 0;
                    p->state = ODTS_PLAYING;
                    printf("[RELAY] Resuming from chunk %zu\n",
                           p->current_chunk);
                }
                continue;
            }
        }

        /* ── read chunk from file ── */
        size_t n = fread(p->chunk_buf, 1, CHUNK_BYTES, p->file);
        if (n == 0) break;

        /* ── real-time LTE verify before "playing" ── */
        const LTEArtifact *a = &p->chain.artifacts[p->current_chunk];
        LTEResult vr = lte_verify(a, p->chunk_buf, n);

        print_state(p->state);
        printf("chunk %04zu/%04zu  %s  hash:%.12s...",
               p->current_chunk + 1,
               p->chain.count,
               vr == LTE_OK ? "VERIFIED " : "TAMPERED!",
               a->link_hex);

        if (vr != LTE_OK) {
            p->tamper_count++;
            p->state = ODTS_REJECTED;
            printf("  [HALT — chain broken]\n");
            break;
        }

        /* ── EXECUTE: chunk is verified, mark as executing ── */
        /* We operate on a copy since chain artifacts are const-like */
        p->frames_verified++;
        p->frames_played++;

        /* simulate playback timing based on speed */
        double chunk_duration_ms =
            ((double)n / (double)p->header.byte_rate) * 1000.0
            / p->playback_speed;
        long sleep_ns = (long)(chunk_duration_ms * 1e6);
        if (sleep_ns > 0) {
            struct timespec ts = { sleep_ns / 1000000000L,
                                   sleep_ns % 1000000000L };
            nanosleep(&ts, NULL);
        }

        printf("  [%.0fms]\n", chunk_duration_ms);
        p->current_chunk++;
    }

    return 0;
}

/* ─── Main ────────────────────────────────────────────────────────────────── */

int main(int argc, char *argv[]) {
    printf("NSIGII LTE Audio Verifier\n");
    printf("OBINexus SDK | MMUKO OS | Linkable Then Executable\n");
    printf("====================================================\n\n");

    if (argc < 2) {
        /* No WAV provided — run self-test with a synthetic WAV */
        printf("[INFO] No WAV file provided. Running synthetic self-test.\n");
        printf("Usage: %s <audio.wav>\n\n", argv[0]);

        /* Build a minimal valid WAV in memory and write to temp file */
        const char *tmp = "/tmp/nsigii_test.wav";
        FILE *f = fopen(tmp, "wb");
        if (!f) { fprintf(stderr, "Cannot create temp WAV\n"); return 1; }

        uint32_t num_samples  = SAMPLE_RATE * 2; /* 2 seconds */
        uint32_t data_size    = num_samples * 2; /* 16-bit mono */

        WAVHeader h;
        memset(&h, 0, sizeof(h));
        memcpy(h.riff, "RIFF", 4);
        h.file_size      = 36 + data_size;
        memcpy(h.wave, "WAVE", 4);
        memcpy(h.fmt,  "fmt ", 4);
        h.fmt_size       = 16;
        h.audio_format   = 1;
        h.num_channels   = 1;
        h.sample_rate    = SAMPLE_RATE;
        h.bits_per_sample= 16;
        h.byte_rate      = SAMPLE_RATE * 2;
        h.block_align    = 2;
        memcpy(h.data, "data", 4);
        h.data_size      = data_size;
        fwrite(&h, sizeof(h), 1, f);

        /* write sine wave samples */
        for (uint32_t i = 0; i < num_samples; i++) {
            double t   = (double)i / SAMPLE_RATE;
            double val = 0.5 * 32767.0 *
                         (0.6 * /* 440Hz A */ (t * 440.0 * 2.0 * 3.14159265)
                          - (int)(t * 440.0 * 2.0 * 3.14159265));
            int16_t s = (int16_t)val;
            fwrite(&s, 2, 1, f);
        }
        fclose(f);
        printf("[INFO] Synthetic WAV created: %s (2 seconds, 440Hz)\n\n", tmp);
        argv[1] = (char *)tmp;
    }

    /* ── setup signal handler for PAUSE ── */
    signal(SIGINT,  signal_handler);
    signal(SIGTERM, signal_handler);

    /* ── init player ── */
    NSIGIIPlayer player;
    memset(&player, 0, sizeof(player));
    player.state = ODTS_STOPPED;

    if (wav_open(&player, argv[1]) != 0) return 1;

    /* ── Phase 1: LINK all chunks (constitutional pre-condition) ── */
    if (lte_link_all_chunks(&player) != 0) {
        fprintf(stderr, "[LTE] Link phase failed. Cannot execute.\n");
        fclose(player.file);
        return 1;
    }

    /* ── Phase 2: EXECUTE (play with per-chunk verify) ── */
    lte_play(&player);

    /* ── Report ── */
    printf("\n====================================================\n");
    printf("NSIGII LTE Playback Report\n");
    printf("  State          : %s\n",
           player.state == ODTS_REJECTED ? "REJECTED (tamper detected)"
           : player.current_chunk >= player.chain.count ? "COMPLETE"
           : "STOPPED");
    printf("  Chunks linked  : %zu\n", player.chain.count);
    printf("  Chunks played  : %zu\n", player.frames_played);
    printf("  Chunks verified: %zu\n", player.frames_verified);
    printf("  Tamper events  : %zu\n", player.tamper_count);
    printf("  Consensus      : %s\n",
           player.tamper_count == 0 ? "OK — chain intact" : "BROKEN");

    fclose(player.file);
    return player.tamper_count == 0 ? 0 : 1;
}
